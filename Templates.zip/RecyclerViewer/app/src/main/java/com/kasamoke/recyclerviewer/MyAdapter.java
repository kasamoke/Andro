package com.kasamoke.recyclerviewer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private String[] data;
    public MyAdapter(String[] data){
        this.data=data;
    }
    //below function fetches the layout file and create an object of holder
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_list,parent,false);
        return new MyViewHolder(view);
    }

    //this will set the data on scrolling
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            String title = data[position];
            holder.txt.setText(title);
            //we can set image also

    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView imgicon;
        TextView txt;
        //after the layout is fetched references to the items got pulled
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imgicon = itemView.findViewById(R.id.img);
            txt=itemView.findViewById(R.id.txt);
        }
    }
}
