package gd.rf.kasamokeport.locator;

public class contact {

   private String name;
   private String email;
   private String mnumber;
   private String hnumber;

    void setData(String name,String email,String mnumber,String hnumber)
    {
        this.name=name;
        this.email=email;
        this.mnumber=mnumber;
        this.hnumber=hnumber;
    }

    String getName()
    {
        return name;
    }
    String getEmail()
    {
        return email;
    }
    String getMnumber()
    {
        return mnumber;
    }
    String getHnumber()
    {
        return hnumber;
    }
}
