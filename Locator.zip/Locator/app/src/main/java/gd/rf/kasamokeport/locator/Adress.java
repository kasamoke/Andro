package gd.rf.kasamokeport.locator;


public class Adress {

    String lat,lon;
    double Latitude,Longitude;

    void setLat(String lat)
    {
        this.lat = lat;
         if(this.lat.length() == 9)
        {
            Latitude = Double.parseDouble(this.lat);
            Latitude = Latitude / 1000000;
        }
        else if(this.lat.length() == 8)
        {
            Latitude = Double.parseDouble(this.lat);
            Latitude = Latitude / 1000000;
        }
    }
    void setLong(String lon)
    {
        this.lon = lon;
        if(this.lon.length() == 9)
        {
            Longitude = Double.parseDouble(this.lat);
            Longitude = Longitude / 1000000;
        }
        else if(this.lon.length() == 8)
        {
            Longitude = Double.parseDouble(this.lat);
            Longitude = Longitude / 1000000;
        }
    }

    double getLat()
    {
        return Latitude;
    }

    double getLong()
    {
        return Longitude;
    }


}
