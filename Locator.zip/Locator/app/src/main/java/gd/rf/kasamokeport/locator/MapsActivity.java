
package gd.rf.kasamokeport.locator;

import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

   // private GoogleMap mMap1,nMap2,nMap3,nMap4,nMap5;
    Adress one,two,three,four,five;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        Intent intent = getIntent();

        one = new Adress();
        two = new Adress();
        three = new Adress();
        four = new Adress();
        five = new Adress();
        one.setLat((String) intent.getExtras().get("One Lat"));
        one.setLong((String) intent.getExtras().get("One Long"));
       // Log.d("error !!Niraj",  Double.toString(one.getLat()));
       // Log.d("error !!Niraj",  Double.toString(one.getLong()));

        two.setLat(intent.getStringExtra("Two Lat"));
        two.setLong(intent.getStringExtra("Two Long"));
       // Log.d("error !!Niraj",  Double.toString(two.getLong()));

        three.setLat(intent.getStringExtra("Three Lat"));
        three.setLong(intent.getStringExtra("Three Long"));

        four.setLat(intent.getStringExtra("Four Lat"));
        four.setLong(intent.getStringExtra("Four Long"));

        five.setLat(intent.getStringExtra("Five Lat"));
        five.setLong(intent.getStringExtra("Five Long"));


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
//        mMap1 = googleMap;
//        nMap2 = googleMap;
//        nMap3 = googleMap;
//        nMap4 = googleMap;
//        nMap5 = googleMap;

        LatLng place1 = new LatLng(one.getLat(), one.getLong());
        Marker m1 = googleMap.addMarker(new MarkerOptions()
                .position(place1)
                .title("It's Dan"));

        LatLng place2 = new LatLng(two.getLat(),two.getLong());
        Marker m2 = googleMap.addMarker(new MarkerOptions()
                .position(place2)
                .title("For John"));

        LatLng place3 = new LatLng(three.getLat(),three.getLong());
        Marker m3 = googleMap.addMarker(new MarkerOptions()
                .position(place3)
                .title("For Daniel"));

        LatLng place4 = new LatLng(four.getLat(),four.getLong());
        Marker m4 = googleMap.addMarker(new MarkerOptions()
                .position(place4)
                .title("For Johnny"));

        LatLng place5 = new LatLng(five.getLat(),five.getLong());
        Marker m5 = googleMap.addMarker(new MarkerOptions()
                .position(place5)
                .title("For Makiyo"));


//        // Add a marker in Sydney and move the camera
//        LatLng place1 = new LatLng(one.getLat(), one.getLong());
//        mMap1.addMarker(new MarkerOptions().position(place1).title("First Marker"));
//        mMap1.moveCamera(CameraUpdateFactory.newLatLng(place1));
//
//        //add one more marker
//        LatLng place2 = new LatLng(two.getLat(),two.getLong());
//        nMap2.addMarker(new MarkerOptions().position(place2).title("Second Marker"));
//        nMap2.moveCamera(CameraUpdateFactory.newLatLng(place2));
//
//        LatLng place3 = new LatLng(three.getLat(),three.getLong());
//        nMap3.addMarker(new MarkerOptions().position(place3).title("Three Marker"));
//        nMap3.moveCamera(CameraUpdateFactory.newLatLng(place3));
//
//        LatLng place4 = new LatLng(four.getLat(),four.getLong());
//        nMap4.addMarker(new MarkerOptions().position(place4).title("Four Marker"));
//        nMap4.moveCamera(CameraUpdateFactory.newLatLng(place4));
//
//        LatLng place5 = new LatLng(five.getLat(),five.getLong());
//        nMap5.addMarker(new MarkerOptions().position(place5).title("Five Marker"));
//        nMap5.moveCamera(CameraUpdateFactory.newLatLng(place5));

       // Toast.makeText(getApplicationContext(), ((int) four.getLong()),Toast.LENGTH_SHORT).show();


    }
}
