
package gd.rf.kasamokeport.locator;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentProviderOperation;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    String url="http://www.cs.columbia.edu/~coms6998-8/assignments/homework2/contacts/contacts.txt";
    Button Reqbtn,setcontacts;
    StringRequest stringRequest;
    contact one,two,three,four,five;
    ProgressDialog pd;

    String[] permissions = new String[]{
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.READ_CONTACTS
    };
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try{
            checkPermissions();
        }catch (Exception e){Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();}

        Reqbtn=(Button)findViewById(R.id.getdataBtn);
        setcontacts=(Button)findViewById(R.id.setContacts);
        //creating each contacts objects
         one = new contact();
         two = new contact();
         three = new contact();
         four = new contact();
         five = new contact();
       pd =  new ProgressDialog(MainActivity.this);
       setcontacts.setVisibility(View.INVISIBLE);
        Reqbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    pd.setMessage("Doing Something, we'll be right back soon");
                    pd.show();
                     stringRequest = new StringRequest(Request.Method.GET, url,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Reqbtn.setVisibility(View.INVISIBLE);
                                    setcontacts.setVisibility(View.VISIBLE);
                                    pd.dismiss();
                                    String[] splitStr = response.split("\\s+");
                                    //It is HARDCODED, we can also automate it.
                                    one.setData(splitStr[0],splitStr[1],splitStr[2],splitStr[3]);
                                    two.setData(splitStr[4],splitStr[5],splitStr[6],splitStr[7]);
                                    three.setData(splitStr[8],splitStr[9],splitStr[10],splitStr[11]);
                                    four.setData(splitStr[12],splitStr[13],splitStr[14],splitStr[15]);
                                    five.setData(splitStr[16],splitStr[17],splitStr[18],splitStr[19]);
                                    Toast.makeText(getApplicationContext(),"Got The Data, Now you can Save it", Toast.LENGTH_LONG).show();
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Reqbtn.setVisibility(View.VISIBLE);
                            pd.setMessage("Something went wrong, Try Again");
                            pd.dismiss();
                            Toast.makeText(MainActivity.this, "FAILURE", Toast.LENGTH_SHORT).show();
                            error.printStackTrace();
                        }
                    });
                }catch (Exception e){Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();}
                Mysingleton.getInstance(MainActivity.this).addtorequestqueue(stringRequest);
            }
        });
        //for savings the data to contacts
        setcontacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                saveContacts(one);
                saveContacts(two);
                saveContacts(three);
                saveContacts(four);
                saveContacts(five);
//
                Intent intent = new Intent(MainActivity.this,MapsActivity.class);
                //String latnp=one.getMnumber(),longnp=one.getHnumber();
                intent.putExtra("One Lat",one.getMnumber());
                intent.putExtra("One Long",one.getHnumber());

//                Log.d("error !!Niraj", one.getHnumber());
//                Log.d("error !!Niraj", one.getMnumber());

                intent.putExtra("Two Lat",two.getMnumber());
                intent.putExtra("Two Long",two.getHnumber());

                intent.putExtra("Three Lat",three.getMnumber());
                intent.putExtra("Three Long",three.getHnumber());

                intent.putExtra("Four Lat",four.getMnumber());
                intent.putExtra("Four Long",four.getHnumber());

                intent.putExtra("Five Lat",five.getMnumber());
                intent.putExtra("Five Long",five.getHnumber());

                startActivity(intent);

                finish();
            }

        });
    }
    private boolean checkPermissions() {
        int result;
        List<String> listPermissionsNeeded = new ArrayList<>();
        for (String p : permissions) {
            result = ContextCompat.checkSelfPermission(this, p);
            if (result != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(p);
            }
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 100);
            return false;
        }
        return true;
    }
    //for saving contacts
    void saveContacts(contact ob) {
        ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();

        ops.add(ContentProviderOperation.newInsert(
                ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build());

        //for name
        if (ob.getName() != null) {
            ops.add(ContentProviderOperation.newInsert(
                    ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(
                            ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,
                            ob.getName()).build());
        }
        //for email
        if (ob.getEmail() != null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Email.DATA, ob.getEmail())
                    .withValue(ContactsContract.CommonDataKinds.Email.TYPE, ContactsContract.CommonDataKinds.Email.TYPE_WORK)
                    .build());
        }
        //for mobile number
        if (ob.getMnumber() != null) {
            ops.add(ContentProviderOperation.
                    newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, ob.getMnumber())
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                    .build());
        }
        //for home number
        if (ob.getHnumber() != null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, ob.getHnumber())
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_HOME)
                    .build());
        }
        try {
            getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
            // Toast.makeText(getApplicationContext(),"Done :),Check Your Contacts", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    }